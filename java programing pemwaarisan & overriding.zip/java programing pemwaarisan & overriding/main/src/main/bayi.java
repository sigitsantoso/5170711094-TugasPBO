
package main;

public class bayi extends manusia{
    static void nama(){
        System.out.println(" BAYI");

 }
    
    @Override
    protected void umur(){
     System.out.println("umur : < 1 tahun");
 }    
         static void aktivitas(){
        System.out.println("aktivitas : makan,tidur ");

 }
}
