
package main;

public class dewasa extends manusia  {
   static void nama(){
        System.out.println(" DEWASA ");

 }
    
   @Override
    protected void umur(){
     System.out.println("umur : 21- 60 tahun");
     
 }     
             static void aktivitas(){
        System.out.println("aktivitas :makan,tidur,bermain,sekolah,bekerja ");

 }
}
