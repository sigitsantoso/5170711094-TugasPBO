
package main;

public class anak_anak extends manusia {
    static void nama(){
        System.out.println(" ANAK ANAK");

 }
    
    @Override
    protected  void umur(){
     System.out.println("umur : 2 - 13 tahun ");
     
 }
         static void aktivitas(){
        System.out.println("aktivitas : makan ,tidur,bermain ");

 }
}
