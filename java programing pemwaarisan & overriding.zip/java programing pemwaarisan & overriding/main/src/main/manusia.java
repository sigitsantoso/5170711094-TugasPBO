
package main;


public class manusia {
 
   static void nama(){
        System.out.println(" jenis manusia berdasarkan umur");

 }
    
    protected void umur(){
     System.out.println("umur : ");
     
 }   
     static void aktivitas(){
        System.out.println("aktivitas : ");

 }
}
