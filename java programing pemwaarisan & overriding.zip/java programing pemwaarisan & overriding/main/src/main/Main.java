package main;

public class Main {

    public static void main(String[] args) {
        manusia mausia = new manusia();
        bayi bayi = new bayi();
        anak_anak anak = new anak_anak();
        remaja remaja = new remaja();
        dewasa dewasa = new dewasa();
        orangtua tua = new orangtua();

        manusia.nama();
        manusia.aktivitas();
        System.out.println("---------------");
        
        System.out.print("1. ");
        bayi.nama();
        bayi.aktivitas();
        System.out.println("");
        
        System.out.print("1. ");
        anak.nama();
        anak.aktivitas();
        System.out.println("");
        
        System.out.print("1. ");
        remaja.nama();
        remaja.aktivitas();
        System.out.println("");
        
        System.out.print("1. ");
        dewasa.nama();
        dewasa.aktivitas();
        System.out.println("");
        
        System.out.print("1. ");
        tua.nama();
        tua.aktivitas();

    }

}
