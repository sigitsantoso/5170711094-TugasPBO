
package main;

public class remaja extends manusia  {
   static void nama(){
        System.out.println(" REMAJA ");

 }
    
   @Override
    protected void umur(){
     System.out.println("umur :14 - 19 tahun ");
     
 }    
         static void aktivitas(){
        System.out.println("aktivitas :makan,tidur,bermain,sekolah ");

 }
}
